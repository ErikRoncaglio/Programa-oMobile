package com.example.listagem;

import android.view.View;
import android.widget.AdapterView;

public class TratamentoClickItemListaNome implements AdapterView.OnItemClickListener{
@Override
public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
}
}

