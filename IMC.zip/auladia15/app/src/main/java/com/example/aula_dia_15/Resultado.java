package com.example.aula_dia_15;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Resultado extends AppCompatActivity {
    TextView tvaltura, tvpeso, tvimc, tvresultado;
    ImageView imageViewResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);


        imageViewResultado=findViewById(R.id.imageView);
        tvaltura = findViewById(R.id.ResultadoAltura);
        tvpeso = findViewById(R.id.Resultadopeso);
        tvimc = findViewById(R.id.ResultadoIMC);
        tvresultado=findViewById(R.id.ResultadoPerfil);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        Float peso, altura, imc;
        peso = bundle.getFloat("peso");
        altura = bundle.getFloat("altura");
        imc = bundle.getFloat("imc");
        imc = peso / (altura * altura);

        tvaltura.setText(altura.toString());
        tvpeso.setText(peso.toString());
        tvimc.setText(imc.toString());

        if (imc<18.5) {
            Toast.makeText(this, "Abaixo do peso", Toast.LENGTH_SHORT).show();
            imageViewResultado.setImageResource(R.drawable.abaixopeso);
            tvresultado.setText("Abaixo do peso");
        } else if (imc>18.5 && imc<24.9){
            Toast.makeText(this, "Peso normal", Toast.LENGTH_SHORT).show();
            imageViewResultado.setImageResource(R.drawable.normal);
            tvresultado.setText("Peso normal");
        }else if (imc>24.9 && imc<29.9){
            Toast.makeText(this, "Sobrepeso", Toast.LENGTH_SHORT).show();
            imageViewResultado.setImageResource(R.drawable.sobrepeso);
            tvresultado.setText("Sobrepeso");
        }else if (imc>30 && imc<34.9){
            Toast.makeText(this, "Obesidade grau 1", Toast.LENGTH_SHORT).show();
            imageViewResultado.setImageResource(R.drawable.obesidade1);
            tvresultado.setText("Obesidade grau 1");
        } else if (imc>35 && imc<39.9){
            Toast.makeText(this, "Obesidade grau 2", Toast.LENGTH_SHORT).show();
            imageViewResultado.setImageResource(R.drawable.obesidade2);
            tvresultado.setText("Obesidade grau 2");
        }else if (imc>40){
            Toast.makeText(this, "Obesidade grau 3", Toast.LENGTH_SHORT).show();
            imageViewResultado.setImageResource(R.drawable.obesidade3);
            tvresultado.setText("Obesidade grau 3");
        }

    }
    public void voltar(View view){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}
